﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanlisinhvien
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void view_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in view.SelectedItems)
            {
                txtmasv.Text = item.SubItems[1].Text;
                txthoten.Text = item.SubItems[2].Text;
                txtngaysinh.Text = item.SubItems[3].Text;
                txtmalop.Text = item.SubItems[4].Text;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            SINHVIEN ob = new SINHVIEN();
            ob.Hienthi(view);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SINHVIEN ob = new SINHVIEN(txtmasv.Text, txthoten.Text, txtmalop.Text, Convert.ToDateTime(txtngaysinh.Text));
            ob.Insert(ob);
            ob.Hienthi(view);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon xoa khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                try
                {
                    SINHVIEN ob = new SINHVIEN(txtmasv.Text, txthoten.Text, txtmalop.Text, Convert.ToDateTime(txtngaysinh.Text));
                    ob.delete(ob);
                    ob.Hienthi(view);
                }
                catch (System.FormatException)
                {

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon sua khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                try
                {
                    SINHVIEN ob = new SINHVIEN(txtmasv.Text, txthoten.Text, txtmalop.Text, Convert.ToDateTime(txtngaysinh.Text));
                    ob.update(ob);
                    ob.Hienthi(view);
                }
                catch (System.FormatException)
                {
                    DialogResult tb = MessageBox.Show("chua nhap du thong tin", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }
}
