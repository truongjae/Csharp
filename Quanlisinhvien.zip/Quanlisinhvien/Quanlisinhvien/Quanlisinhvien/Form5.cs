﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace Quanlisinhvien
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        DIEMTP ob = new DIEMTP();
        private void Form5_Load(object sender, EventArgs e)
        {
            chonlop.DataSource = ob.LoadTable("select * from LOP");
            chonlop.DisplayMember = "tenlop";
            chonlop.ValueMember = "malop";
            chonmon.DataSource = ob.LoadTable("select * from MON");
            chonmon.DisplayMember = "tenmon";
            chonmon.ValueMember = "mamon";
            this.reportViewer1.RefreshReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql1;
            sql1 = "select Sinhvien.Masv,Hoten,CONVERT(varchar,Ngaysinh,101) as Ngaysinh";
            sql1 = sql1 + " from Sinhvien,Diem,Diemcuoiky,Mon";
            sql1 = sql1 + " where Sinhvien.Masv = Diemcuoiky.Masv and ";
            sql1 = sql1 + " Diemcuoiky.Mamon=Mon.Mamon and Diemcuoiky.Masv=Diem.masv and ";
            sql1 = sql1 + " Sinhvien.Malop='" + chonlop.SelectedValue.ToString();
            sql1 = sql1 + " ' and Mon.Mamon='" + chonmon.SelectedValue.ToString() + "'";
            sql1 = sql1 + " and (Diem.DiemCC*0.1+Diem.DiemKT*0.1+Diem.DiemBT*0.1+Diemcuoiky.DiemL1*0.7)<4";
            DataTable dt = new DataTable();
            dt = ob.LoadTable(sql1); // Sql chuyển Database thành DataSet
            //Khai báo mode làm việc của reportview
            reportViewer1.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
            reportViewer1.LocalReport.ReportPath = @"E:\hoc Csharp\Quanlisinhvien\Quanlisinhvien\Quanlisinhvien\Report1.rdlc";
            //Truyền giá trị từ form vào biến cho report
            ReportParameter[] rp = new ReportParameter[2];//Tạo 1 mảng tham số
            rp[0] = new ReportParameter("tenlop");//Đây là tham số đầu tiên
            rp[0].Values.Add(chonlop.Text);
            rp[1] = new ReportParameter("tenmon");
            rp[1].Values.Add(chonmon.Text);
            reportViewer1.LocalReport.SetParameters(rp);
            //đặt nguồn cho report và report viewer
            if (dt.Rows.Count > 0)
            {
                //Tạo nguồn dữ liệu cho báo cáo
                ReportDataSource rds = new ReportDataSource();
                rds.Name = "DataSet1"; rds.Value = dt;
                reportViewer1.LocalReport.DataSources.Clear();
                //Add dữ liệu vào
                reportViewer1.LocalReport.DataSources.Add(rds);
                //Refresh lại báo cáo
                reportViewer1.RefreshReport();
            }
            else
                MessageBox.Show("Không có dữ liệu");
        }
        }
    }
