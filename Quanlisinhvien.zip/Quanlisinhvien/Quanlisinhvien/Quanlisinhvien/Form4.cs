﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanlisinhvien
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private void DanhSTT(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells["STT"].Value = e.RowIndex + 1;
        }   
        DIEMTP ob = new DIEMTP();
        private void Form4_Load(object sender, EventArgs e)
        {
            chonlop.DataSource = ob.LoadTable("select * from LOP");
            chonlop.DisplayMember = "tenlop";
            chonlop.ValueMember = "malop";
            chonmon.DataSource = ob.LoadTable("select * from MON");
            chonmon.DisplayMember = "tenmon";
            chonmon.ValueMember = "mamon";
        }
        DataTable dt = new DataTable();
        string malop, mamon;

        private void button1_Click(object sender, EventArgs e)
        {
            dt.Clear();
            string sqltam;
            sqltam = "delete from bangtam";
            ob.Excecute(sqltam);
            malop = chonlop.SelectedValue.ToString();
            mamon = chonmon.SelectedValue.ToString();
            // phai chuot vao datagridview sau do add lan luot cac column stt mamon dat data = ten truong mamon,...

            string sqlconn;
            sqlconn = "insert into BANGTAM(masv) select masv from SINHVIEN where malop='" + malop + "'";
            ob.Excecute(sqlconn);
            sqlconn = "update BANGTAM set mamon='" + mamon + "'";
            ob.Excecute(sqlconn);
            string sql1;
            sql1 = "select SINHVIEN.masv,hoten,convert(varchar,ngaysinh,101) as ngaysinh,bangtam.diemcc,";
            sql1 = sql1 + "BANGTAM.diemkt,BANGTAM.diembt from SINHVIEN, BANGTAM,MON";
            sql1 = sql1 + " where SINHVIEN.masv=BANGTAM.masv and BANGTAM.mamon=MON.mamon ";
            sql1 = sql1 + " and SINHVIEN.malop='" + malop + "' and MON.mamon='" + mamon + "'";
            dt = ob.LoadTable(sql1);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string DCC, DKT, DBT, masv, sql;
            try
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    masv = dataGridView1.Rows[i].Cells["masv"].Value.ToString();
                    DCC = dataGridView1.Rows[i].Cells["diemcc"].Value.ToString();
                    DKT = dataGridView1.Rows[i].Cells["diemkt"].Value.ToString();
                    DBT = dataGridView1.Rows[i].Cells["diembt"].Value.ToString();
                    sql = "insert into DIEM values('" + masv + "','" + mamon + "',";
                    sql += Convert.ToSingle(DCC) + "," + Convert.ToSingle(DKT) + ",";
                    sql += Convert.ToSingle(DBT) + ")";
                    ob.Excecute(sql);
                }
                MessageBox.Show("Luu diem thanh cong");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
