﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanlisinhvien
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void view_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in view.SelectedItems)
            {
                txtmamon.Text = item.SubItems[1].Text;
                txttenmon.Text = item.SubItems[2].Text;
                txtsotc.Text = item.SubItems[3].Text;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            MON ob = new MON();
            ob.Hienthi(view);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MON ob = new MON(txtmamon.Text, txttenmon.Text, int.Parse(txtsotc.Text));
            ob.Insert(ob);
            ob.Hienthi(view);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon sua khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                try
                {
                    MON ob = new MON(txtmamon.Text, txttenmon.Text, int.Parse(txtsotc.Text));
                    ob.update(ob);
                    ob.Hienthi(view);
                }
                catch (System.FormatException)
                {
                    DialogResult tb = MessageBox.Show("chua nhap du thong tin", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon xoa khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                try
                {
                    MON ob = new MON(txtmamon.Text, txttenmon.Text, int.Parse(txtsotc.Text));
                    ob.delete(ob);
                    ob.Hienthi(view);
                }
                catch (System.FormatException)
                {

                }
            }
        }
    }
}
