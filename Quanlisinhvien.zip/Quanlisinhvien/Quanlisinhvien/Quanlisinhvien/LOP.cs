﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Quanlisinhvien
{
    class LOP
    {
        string malop, tenlop;
        public LOP() { }

        public LOP(string malop, string tenlop)
        {
            this.malop = malop;
            this.tenlop = tenlop;
        }
        //Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True
        SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
        public void Hienthi(ListView item)
        {
            item.Items.Clear();
            try
            {
                conn.Open();
            }
            catch (System.InvalidOperationException)
            {
                //
            }
            SqlCommand cmd = new SqlCommand("select * from LOP", conn);
            SqlDataReader Doc = cmd.ExecuteReader();

            int i = 0;
            while (Doc.Read())
            {
                item.Items.Add((i + 1).ToString());
                item.Items[i].SubItems.Add(Doc[0].ToString());
                item.Items[i].SubItems.Add(Doc[1].ToString());
                i++;
            }
            conn.Close();

            //System.InvalidOperationException
        }
        //lenh insert 
        public void Insert(LOP ob)
        {
            string sql = "Insert into LOP values(@ml,@tl)";
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@ml", SqlDbType.NVarChar, 20).Value = ob.malop;
            cmd.Parameters.Add("@tl", SqlDbType.NVarChar, 30).Value = ob.tenlop;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                DialogResult tl = MessageBox.Show("ma lop khong hop le", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }

        }
        //lenh update
        public void update(LOP ob)
        {
            string sql = "Update LOP set tenlop='" + ob.tenlop + "' where malop='" + ob.malop + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        // lenh delete
        public void delete(LOP ob)
        {
            string sql = "DELETE from LOP where malop='" + ob.malop + "' and tenlop ='" + ob.tenlop + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                //
            }
            conn.Close();
        }
    }
}
