﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Quanlisinhvien
{
    class MON
    {
        string mamon, tenmon;
        int sotc;
        public MON() { }
        public MON(string mamon, string tenmon, int sotc)
        {
            this.mamon = mamon;
            this.tenmon = tenmon;
            this.sotc = sotc;
        }
        //Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True
        SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
        public void Hienthi(ListView item)
        {
            item.Items.Clear();
            try
            {
                conn.Open();
            }
            catch (System.InvalidOperationException)
            {
                //
            }
            SqlCommand cmd = new SqlCommand("select * from MON", conn);
            SqlDataReader Doc = cmd.ExecuteReader();

            int i = 0;
            while (Doc.Read())
            {
                item.Items.Add((i + 1).ToString());
                item.Items[i].SubItems.Add(Doc[0].ToString());
                item.Items[i].SubItems.Add(Doc[1].ToString());
                item.Items[i].SubItems.Add(Doc[2].ToString());
                i++;
            }
            conn.Close();

            //System.InvalidOperationException
        }
        //lenh insert 
        public void Insert(MON ob)
        {
            string sql = "Insert into MON values(@mm,@tm,@tc)";
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@mm", SqlDbType.NVarChar, 20).Value = ob.mamon;
            cmd.Parameters.Add("@tm", SqlDbType.NVarChar, 30).Value = ob.tenmon;
            cmd.Parameters.Add("@tc", SqlDbType.NVarChar, 30).Value = ob.sotc;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                DialogResult tl = MessageBox.Show("ma mon khong hop le", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }

        }
        //lenh update
        public void update(MON ob)
        {
            string sql = "Update MON set tenmon='" + ob.tenmon + "sotc='" + ob.sotc + "' where mamon='" + ob.mamon + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        // lenh delete
        public void delete(MON ob)
        {
            string sql = "DELETE from MON where mamon='" + ob.mamon + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                //
            }
            conn.Close();
        }
    }
}
