﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace Quanlisinhvien
{
    class BANGDIEMTL
    {
        public SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
        public DataTable LoadTable(string sql)
        {
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(sql, conn);
            try
            {
                ad.Fill(dt);
            }
            catch (Exception ex) { }
            conn.Close();
            return dt;
        }
    }
}
