﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Quanlisinhvien
{
    class SINHVIEN
    {
        string masv, hoten, malop;
        DateTime ngaysinh;
        public SINHVIEN() { }
        public SINHVIEN(string masv, string hoten, string malop, DateTime ngaysinh)
        {
            this.masv = masv;
            this.hoten = hoten;
            this.malop = malop;
            this.ngaysinh = ngaysinh;
        }
        //Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True
        SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
        public void Hienthi(ListView item)
        {
            item.Items.Clear();
            try
            {
                conn.Open();
            }
            catch (System.InvalidOperationException)
            {
                //
            }
            SqlCommand cmd = new SqlCommand("select * from SINHVIEN", conn);
            SqlDataReader Doc = cmd.ExecuteReader();

            int i = 0;
            while (Doc.Read())
            {
                item.Items.Add((i + 1).ToString());
                item.Items[i].SubItems.Add(Doc[0].ToString());
                item.Items[i].SubItems.Add(Doc[1].ToString());
                item.Items[i].SubItems.Add(Doc[2].ToString());
                item.Items[i].SubItems.Add(Doc[3].ToString());
                i++;
            }
            conn.Close();

            //System.InvalidOperationException
        }
        //lenh insert 
        public void Insert(SINHVIEN ob)
        {
            string sql = "Insert into SINHVIEN values(@msv,@ht,@ns,@ml)";
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@msv", SqlDbType.NVarChar, 20).Value = ob.masv;
            cmd.Parameters.Add("@ht", SqlDbType.NVarChar, 30).Value = ob.hoten;
            cmd.Parameters.Add("@ns", SqlDbType.DateTime).Value = ob.ngaysinh;
            cmd.Parameters.Add("@ml", SqlDbType.NVarChar, 30).Value = ob.malop;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                DialogResult tl = MessageBox.Show("ma sinh vien khong hop le", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }

        }
        //lenh update
        public void update(SINHVIEN ob)
        {
            string sql = "Update SINHVIEN set hoten='" + ob.hoten + "',malop='" + ob.malop + "' where masv='" + ob.masv + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        // lenh delete
        public void delete(SINHVIEN ob)
        {
            string sql = "DELETE from SINHVIEN where masv='" + ob.masv + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                //
            }
            conn.Close();
        }

        public DataTable Load_Table(String sql)
        {
            SINHVIEN ob = new SINHVIEN();
            ob.conn.Open();
            SqlDataAdapter ad = new SqlDataAdapter(sql, ob.conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            ob.conn.Close();
            return dt;
        }
    }
}
