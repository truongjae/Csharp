﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace Quanlisinhvien
{
    class DIEMTP
    {
        public DIEMTP()
        {

        }
        public SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
        public DataTable LoadTable(string sql)
        {
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(sql, conn);
            try
            {
                ad.Fill(dt);
            }
            catch (System.Data.SqlClient.SqlException) { }
            conn.Close();
            return dt;
        }
        public void Excecute(string sql)
        {
            conn.Open();
            SqlCommand thuchienlenh = new SqlCommand(sql, conn);
            try
            {
                thuchienlenh.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException) { }
            conn.Close();
        }
    }
}
