﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanliduan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DUAN ob = new DUAN();
            ob.HienThi(view);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DUAN ob = new DUAN(txtmada.Text,txttenda.Text,txtdiadiem.Text);
            ob.Insert(ob);
            ob.HienThi(view);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon sua khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                DUAN ob = new DUAN(txtmada.Text, txttenda.Text, txtdiadiem.Text);
                ob.update(ob);
                ob.HienThi(view);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Ban co muon xoa khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                DUAN ob = new DUAN(txtmada.Text, txttenda.Text, txtdiadiem.Text);
                ob.delete(ob);
                ob.HienThi(view);
            }
        }

        private void view_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in view.SelectedItems)
            {
                txtmada.Text = item.SubItems[1].Text;
                txttenda.Text = item.SubItems[2].Text;
                txtdiadiem.Text = item.SubItems[3].Text;
            }
        }
    }
}
