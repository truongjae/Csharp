﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanliduan
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            NHANVIEN ob = new NHANVIEN();
            ob.HienThi(view);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NHANVIEN ob = new NHANVIEN(txtmanv.Text, txthoten.Text, txtngaysinh.Text);
            ob.Insert(ob);
            ob.HienThi(view);
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            DialogResult tl = MessageBox.Show("Ban co muon xoa khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                NHANVIEN ob = new NHANVIEN(txtmanv.Text, txthoten.Text, txtngaysinh.Text);
                ob.delete(ob);
                ob.HienThi(view);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            DialogResult tl = MessageBox.Show("Ban co muon xoa khong", "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                NHANVIEN ob = new NHANVIEN(txtmanv.Text, txthoten.Text, txtngaysinh.Text);
                ob.update(ob);
                ob.HienThi(view);
            }
        }

        private void view_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in view.SelectedItems)
            {
                txtmanv.Text = item.SubItems[1].Text;
                txthoten.Text = item.SubItems[2].Text;
                txtngaysinh.Text = item.SubItems[3].Text;
            }
        }

    }
}
