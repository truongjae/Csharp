﻿namespace Quanliduan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtmada = new System.Windows.Forms.TextBox();
            this.txtdiadiem = new System.Windows.Forms.TextBox();
            this.txttenda = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.view = new System.Windows.Forms.ListView();
            this.mada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tenda = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.diadiem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.stt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập Mã Dự Án";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nhập Tên Dự Án";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nhập Địa Điểm";
            // 
            // txtmada
            // 
            this.txtmada.Location = new System.Drawing.Point(217, 53);
            this.txtmada.Name = "txtmada";
            this.txtmada.Size = new System.Drawing.Size(143, 22);
            this.txtmada.TabIndex = 3;
            // 
            // txtdiadiem
            // 
            this.txtdiadiem.Location = new System.Drawing.Point(217, 139);
            this.txtdiadiem.Name = "txtdiadiem";
            this.txtdiadiem.Size = new System.Drawing.Size(143, 22);
            this.txtdiadiem.TabIndex = 4;
            // 
            // txttenda
            // 
            this.txttenda.Location = new System.Drawing.Point(217, 97);
            this.txttenda.Name = "txttenda";
            this.txttenda.Size = new System.Drawing.Size(143, 22);
            this.txttenda.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(438, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "NHẬP";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // view
            // 
            this.view.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.stt,
            this.mada,
            this.tenda,
            this.diadiem});
            this.view.FullRowSelect = true;
            this.view.GridLines = true;
            this.view.Location = new System.Drawing.Point(59, 202);
            this.view.Name = "view";
            this.view.Size = new System.Drawing.Size(609, 186);
            this.view.TabIndex = 7;
            this.view.UseCompatibleStateImageBehavior = false;
            this.view.View = System.Windows.Forms.View.Details;
            this.view.SelectedIndexChanged += new System.EventHandler(this.view_SelectedIndexChanged);
            // 
            // mada
            // 
            this.mada.Text = "Mã Dự Án";
            this.mada.Width = 120;
            // 
            // tenda
            // 
            this.tenda.Text = "Tên Dự Án";
            this.tenda.Width = 120;
            // 
            // diadiem
            // 
            this.diadiem.Text = "Địa Điểm";
            this.diadiem.Width = 120;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(438, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "SỬA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(438, 137);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 9;
            this.button3.Text = "XÓA";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 463);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.view);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txttenda);
            this.Controls.Add(this.txtdiadiem);
            this.Controls.Add(this.txtmada);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtmada;
        private System.Windows.Forms.TextBox txtdiadiem;
        private System.Windows.Forms.TextBox txttenda;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView view;
        private System.Windows.Forms.ColumnHeader mada;
        private System.Windows.Forms.ColumnHeader tenda;
        private System.Windows.Forms.ColumnHeader diadiem;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

