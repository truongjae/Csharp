﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Quanliduan
{
    class DUAN
    {
        string mada,tenda,diadiem;
        public DUAN() { }
        public DUAN(string mada, string tenda, string diadiem)
        {
            this.mada = mada;
            this.tenda = tenda;
            this.diadiem = diadiem;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=TRUONGJAE\SQLEXPRESS;Initial Catalog=DUAN;Integrated Security=True");
        public void HienThi(ListView item)
        {
            item.Items.Clear();
            try
            {
                conn.Open();
            }
            catch (System.InvalidOperationException) { }
            SqlCommand cmd = new SqlCommand("select * from DUAN", conn);
            SqlDataReader Doc = cmd.ExecuteReader();
            int i = 0;
            while (Doc.Read()){
                item.Items.Add((i + 1).ToString());
                item.Items[i].SubItems.Add(Doc[0].ToString());
                item.Items[i].SubItems.Add(Doc[1].ToString());
                item.Items[i].SubItems.Add(Doc[2].ToString());
                i++;
            }
            conn.Close();
        }
        public void Insert(DUAN ob)
        {
            string sql = "Insert into DUAN values(@ma,@ta,@dd)";
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@ma", SqlDbType.NVarChar, 30).Value = ob.mada;
            cmd.Parameters.Add("@ta", SqlDbType.NVarChar, 30).Value = ob.tenda;
            cmd.Parameters.Add("@dd", SqlDbType.NVarChar, 50).Value = ob.diadiem;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                DialogResult tl = MessageBox.Show("ma du an khong hop le", "thong bao", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }
        }
        //lenh update
        public void update(DUAN ob)
        {
            string sql = "Update DUAN set tenda='" + ob.tenda + "',diadiem='" + ob.diadiem + "' where mada='" + ob.mada + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        // lenh delete
        public void delete(DUAN ob)
        {
            string sql = "DELETE from DUAN where mada='" + ob.mada + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                //
            }
            conn.Close();
        }

        public DataTable Load_Table(String sql)
        {
            DUAN ob = new DUAN();
            ob.conn.Open();
            SqlDataAdapter ad = new SqlDataAdapter(sql, ob.conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            ob.conn.Close();
            return dt;
        }
    }
}
