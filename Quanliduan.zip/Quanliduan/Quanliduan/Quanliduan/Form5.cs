﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace Quanliduan
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        NVDA ob = new NVDA();
        private void button1_Click(object sender, EventArgs e)
        {
            string sql1;
            sql1 = "select na.mada, na.manv, na.sogiocong,na.dongia from DUAN da, NHANVIEN nv, NVDA na where da.mada = na.mada and nv.manv = na.manv and da.diadiem = 'Ha Noi'";
            DataTable dt = new DataTable();
            dt = ob.LoadTable(sql1); // Sql chuyển Database thành DataSet
            //Khai báo mode làm việc của reportview
            reportViewer1.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
            reportViewer1.LocalReport.ReportPath = @"E:\hoc Csharp\Quanliduan\Quanliduan\Quanliduan\Report1.rdlc";
            //Truyền giá trị từ form vào biến cho report
            //đặt nguồn cho report và report viewer
            if (dt.Rows.Count > 0)
            {
                //Tạo nguồn dữ liệu cho báo cáo
                ReportDataSource rds = new ReportDataSource();
                rds.Name = "DataSet1"; rds.Value = dt;
                reportViewer1.LocalReport.DataSources.Clear();
                //Add dữ liệu vào
                reportViewer1.LocalReport.DataSources.Add(rds);
                //Refresh lại báo cáo
                reportViewer1.RefreshReport();
            }
            else
                MessageBox.Show("Không có dữ liệu");
        }

        private void Form5_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }
    }
}
