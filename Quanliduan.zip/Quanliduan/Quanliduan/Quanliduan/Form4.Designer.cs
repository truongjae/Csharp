﻿namespace Quanliduan
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdongia = new System.Windows.Forms.TextBox();
            this.txtsogio = new System.Windows.Forms.TextBox();
            this.Nhập = new System.Windows.Forms.Button();
            this.chonmada = new System.Windows.Forms.ComboBox();
            this.chonmanv = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.STT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sogiocong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dongia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập Mã Dự Án";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nhập Mã Nhân Viên";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nhập Số Giờ Công";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nhập Đơn Giá";
            // 
            // txtdongia
            // 
            this.txtdongia.Location = new System.Drawing.Point(336, 179);
            this.txtdongia.Name = "txtdongia";
            this.txtdongia.Size = new System.Drawing.Size(100, 22);
            this.txtdongia.TabIndex = 5;
            // 
            // txtsogio
            // 
            this.txtsogio.Location = new System.Drawing.Point(336, 137);
            this.txtsogio.Name = "txtsogio";
            this.txtsogio.Size = new System.Drawing.Size(100, 22);
            this.txtsogio.TabIndex = 6;
            // 
            // Nhập
            // 
            this.Nhập.Location = new System.Drawing.Point(635, 92);
            this.Nhập.Name = "Nhập";
            this.Nhập.Size = new System.Drawing.Size(86, 62);
            this.Nhập.TabIndex = 8;
            this.Nhập.Text = "THEM";
            this.Nhập.UseVisualStyleBackColor = true;
            this.Nhập.Click += new System.EventHandler(this.Nhập_Click);
            // 
            // chonmada
            // 
            this.chonmada.FormattingEnabled = true;
            this.chonmada.Location = new System.Drawing.Point(336, 42);
            this.chonmada.Name = "chonmada";
            this.chonmada.Size = new System.Drawing.Size(121, 24);
            this.chonmada.TabIndex = 9;
            // 
            // chonmanv
            // 
            this.chonmanv.FormattingEnabled = true;
            this.chonmanv.Location = new System.Drawing.Point(336, 85);
            this.chonmanv.Name = "chonmanv";
            this.chonmanv.Size = new System.Drawing.Size(121, 24);
            this.chonmanv.TabIndex = 10;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STT,
            this.mada,
            this.manv,
            this.sogiocong,
            this.dongia});
            this.dataGridView1.Location = new System.Drawing.Point(175, 248);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(546, 216);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.DANHSTT);
            // 
            // STT
            // 
            this.STT.HeaderText = "STT";
            this.STT.Name = "STT";
            // 
            // mada
            // 
            this.mada.DataPropertyName = "mada";
            this.mada.HeaderText = "MÃ DỰ ÁN";
            this.mada.Name = "mada";
            // 
            // manv
            // 
            this.manv.DataPropertyName = "manv";
            this.manv.HeaderText = "MÃ NHÂN VIÊN";
            this.manv.Name = "manv";
            // 
            // sogiocong
            // 
            this.sogiocong.DataPropertyName = "sogiocong";
            this.sogiocong.HeaderText = "SỐ GIỜ CÔNG";
            this.sogiocong.Name = "sogiocong";
            // 
            // dongia
            // 
            this.dongia.DataPropertyName = "dongia";
            this.dongia.HeaderText = "ĐƠN GIÁ";
            this.dongia.Name = "dongia";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 488);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.chonmanv);
            this.Controls.Add(this.chonmada);
            this.Controls.Add(this.Nhập);
            this.Controls.Add(this.txtsogio);
            this.Controls.Add(this.txtdongia);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdongia;
        private System.Windows.Forms.TextBox txtsogio;
        private System.Windows.Forms.Button Nhập;
        private System.Windows.Forms.ComboBox chonmada;
        private System.Windows.Forms.ComboBox chonmanv;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn STT;
        private System.Windows.Forms.DataGridViewTextBoxColumn mada;
        private System.Windows.Forms.DataGridViewTextBoxColumn manv;
        private System.Windows.Forms.DataGridViewTextBoxColumn sogiocong;
        private System.Windows.Forms.DataGridViewTextBoxColumn dongia;
    }
}