﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quanliduan
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void DANHSTT(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells["STT"].Value = e.RowIndex + 1;
        }
        NVDA ob = new NVDA();

        private void Form4_Load(object sender, EventArgs e)
        {
            chonmada.DataSource = ob.LoadTable("select * from DUAN");
            chonmada.DisplayMember = "tenda";
            chonmada.ValueMember = "mada";
            chonmanv.DataSource = ob.LoadTable("select * from NHANVIEN");
            chonmanv.DisplayMember = "tennv";
            chonmanv.ValueMember = "manv";
        }
        DataTable dt = new DataTable();
        int sogio;
        float gia;
        string da, nv;
        private void Nhập_Click(object sender, EventArgs e)
        {
            dt.Clear();
            sogio = int.Parse(txtsogio.Text);
            gia = float.Parse(txtdongia.Text);
            // phai chuot vao datagridview sau do add lan luot cac column stt mamon dat data = ten truong mamon,...
             da = chonmada.SelectedValue.ToString();
              nv = chonmanv.SelectedValue.ToString();
            string sqlconn;
            sqlconn = "INSERT INTO NVDA (mada, manv, sogiocong,dongia) VALUES ('"+da+"' ,'"+nv+"',"+sogio+","+gia+")";
            ob.Excecute(sqlconn);
            //sqlconn = "update BANGTAM set mamon='" + mamon + "'";
            //ob.Excecute(sqlconn);
            string sql1;
            /*sql1 = "select SINHVIEN.masv,hoten,convert(varchar,ngaysinh,101) as ngaysinh,bangtam.diemcc,";
            sql1 = sql1 + "BANGTAM.diemkt,BANGTAM.diembt from SINHVIEN, BANGTAM,MON";
            sql1 = sql1 + " where SINHVIEN.masv=BANGTAM.masv and BANGTAM.mamon=MON.mamon ";
            sql1 = sql1 + " and SINHVIEN.malop='" + malop + "' and MON.mamon='" + mamon + "'";*/
            sql1 = "select mada, manv, sogiocong, dongia from NVDA";
            dt = ob.LoadTable(sql1);
            dataGridView1.DataSource = dt;
        }
        /*public void show()
        {
            string DCC, DKT, DBT, masv, sql;
            try
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    masv = dataGridView1.Rows[i].Cells["masv"].Value.ToString();
                    DCC = dataGridView1.Rows[i].Cells["diemcc"].Value.ToString();
                    DKT = dataGridView1.Rows[i].Cells["diemkt"].Value.ToString();
                    DBT = dataGridView1.Rows[i].Cells["diembt"].Value.ToString();
                   // sql = "insert into DIEM values('" + masv + "','" + mamon + "',";
                    sql += Convert.ToSingle(DCC) + "," + Convert.ToSingle(DKT) + ",";
                    sql += Convert.ToSingle(DBT) + ")";
                    ob.Excecute(sql);
                }
                MessageBox.Show("Luu diem thanh cong");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }*/


        
    }
}
